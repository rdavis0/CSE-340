<header class='site-header'>
    <div class='site-logo'>
        <img src="/phpmotors/images/site/logo.png" alt="php motors logo">
    </div>
    <div class='my-account'>
        <a href="/phpmotors/accounts/index.php?action=login">My Account</a>
    </div>
</header>
<nav class='site-nav'><?php echo $navList; ?></nav>

