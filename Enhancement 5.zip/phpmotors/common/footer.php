<footer class='site-footer'>
    <p>© PHP Motors, All rights reserved.<br>
    All images used are believed to be in "Fair Use." Please notify the author if any are not and they will be removed.<br>
    Last Updated: 30 October, 2021</p>
</footer>