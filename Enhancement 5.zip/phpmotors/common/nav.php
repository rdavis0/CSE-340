<nav class='site-nav'>
    <ul id='nav-list'>
        <li class='active'>Home</li>    
        <li>Classic</li>
        <li>Sports</li>
        <li>SUV</li>
        <li>Trucks</li>
        <li>Used</li>
    </ul>
</nav>

<!-- <script type='text/javascript'>
    let navList = document.getElementById('nav-list');
    let items = navList.getElementsByTagName('li');
    for(var i=0; i<items.length; i++) {
        let li = items[i];
        li.addEventListener('click', () => li.classList.add('active'));
    }
</script> -->